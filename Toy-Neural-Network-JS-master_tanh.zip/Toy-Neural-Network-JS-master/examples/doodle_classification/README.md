https://codingtrain.github.io/Toy-Neural-Network-JS/examples/doodle_classification/
