// Daniel Shiffman
// Nature of Code: Intelligence and Learning
// https://github.com/shiffman/NOC-S17-2-Intelligence-Learning

// This flappy bird implementation is adapted from:
// https://youtu.be/cXgA1d_E-jY&

class Pipe {
  constructor() {

    // How big is the empty space
    let spacing = 80;
	  let x = random(1);
	  if(x<0.35){
		  //pipe up
		  // Where is th center of the empty space 
    let centery_1 = random(spacing, height/2 - spacing);

    // Top and bottom of pipe
    this.top_1 = centery_1 - spacing / 2;
    this.bottom_1 = centery_1 + spacing / 2;
		  
	let centery_2 = height + spacing;
	this.top_2 = 0;
	this.bottom_2 = height/2;	  
	  }
	 else if(x>0.65){
		  //pipe down
	let centery_2 = random(spacing, height/2 - spacing);

    // Top and bottom of pipe
    this.top_2 = centery_2 - spacing/2;
    this.bottom_2 = 30
		  
	let centery_1 = -spacing;
	this.top_1 = 0;
	this.bottom_1 = 0;
	  }
	  else{
		  //both pipes
		     // Where is th center of the empty space 
		   let centery_1 = random(spacing, height/2 - spacing);

    // Top and bottom of pipe
    this.top_1 = centery_1 - spacing / 2;
    this.bottom_1 = centery_1 + spacing / 2;
    let centery_2 = random(spacing, height/2 - spacing);

    // Top and bottom of pipe
    this.top_2 = centery_2 - spacing/2;
    this.bottom_2 = 25;
	  }
    // Starts at the edge
    this.x = width;
    // Width of pipe
    this.w = 80;
    // How fast
    this.speed = 6;
  }

  // Did this pipe hit a bird?
  hits(bird) {
	  if (bird.x > this.x && bird.x < this.x + this.w) {
		  if((bird.y < bird.r *2.5 + this.top_2 + height/2) && (bird.y + bird.r *2.5 > this.top_2 + height/2)){
			  return false;/*tal y como están las pipes, cuando */
			  }
		  else{
   /* else */if((bird.y - bird.r) < this.top_1 || (bird.y + bird.r) > (height - this.bottom_2)){
     
        return true;
      }
    else if(((bird.y + bird.r) > this.bottom_1 && (bird.y - bird.r) < (height/2 + this.top_2))){
    return true;
  }
	  else{
		  return false;
	  }
			  }
	  }
		  }
	  

  show() {
    stroke(255);
    fill(200);
    rect(this.x, this.bottom_1, this.w, height/2 - this.bottom_1);
	 rect(this.x, 0, this.w, this.top_1);
    rect(this.x, height/2, this.w, this.top_2);
	rect(this.x, height - this.bottom_2, this.w, this.bottom_2);
	 
	 
  }

  // Update the pipe
  update() {
    this.x -= this.speed;
  }

  // Has it moved offscreen?
  offscreen() {
    if (this.x < -this.w) {
      return true;
    } else {
      return false;
    }
  }
}